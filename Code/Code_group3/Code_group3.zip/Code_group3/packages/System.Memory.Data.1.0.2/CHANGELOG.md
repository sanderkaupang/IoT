# Release History

## 1.0.2 (2021-04-07)
- Add System.Text.Encodings.Web dependency

## 1.0.1 (2020-11-16)
- Fix issue where if the type was not passed into the constructor, an exception would be thrown instead of defaulting to
calling GetType().

## 1.0.0 (2020-11-03)
- The general availability release of System.Memory.Data package.

## 1.0.0-beta.2 (2020-11-03)
- Update package icon.

## 1.0.0-beta.1 (2020-11-02)
- Moving BinaryData to System namespace.
